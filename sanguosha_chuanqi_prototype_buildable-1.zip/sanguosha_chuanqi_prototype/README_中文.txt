三国杀传奇个人验证版（独立离线原型）
版本：0.1

重要说明：
- 这是独立的离线验证版，不是官方游戏，也不是原版服务端。
- 当前包含示例武将、回合制战斗、胜负判定和本地存档。
- 尚未还原原版 .jsc 数据；不得把示例武将误认为原版完整数据。

本地预览：
打开 app/src/main/assets/index.html，或直接打开项目外的 sanguosha_chuanqi_prototype.html。

生成 APK：
项目已附 GitHub Actions 工作流 .github/workflows/build-apk.yml。将整个项目上传到你自己的 GitHub 仓库后，在仓库 Actions 页面运行 “Build Android APK”。成功后下载名为 sanguosha-chuanqi-prototype-debug-apk 的 artifact，里面是 app-debug.apk。该 APK 为调试签名版本，可在 Android 手机上手动安装；首次安装时系统可能提示允许来自该来源的安装。

本地 Android 构建要求：
- JDK 17
- Gradle 8.9
- Android SDK Platform 35 与 Build Tools 35.0.0
然后在项目根目录运行：gradle assembleDebug

本项目目前不包含已经编译完成的 APK。当前执行环境没有 Android SDK/Gradle，且无法从官方站点下载构建工具，因此不能在此环境中诚实地声称已经生成或测试了 APK。
